Thank you for downloading DEADEUS!

This game comes as a zipped ROM, To play it you will need an emulator.

For PC I recommend BGB Emulator and even include a configuration file in the folder for the best set up.

For Android devices I recommend MyBoy! Emulator. Just drop your zipped Deadeus folder into the correct emulator
folder and enjoy!


Please enjoy Deadeus and feel free to reach out about any issues or bugs
on my itch.io page.

-IZMA-

Version 1.3.8
